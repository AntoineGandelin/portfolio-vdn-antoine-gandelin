<html>
<head>
	<title></title>
</head>
<body>
	<!-- Bannière promotionnelle d'abonnement desktop -->
	<div class="r-selligent--surf-connecte-content -only-desktop" style="background-color: transparent;">
		<p class="title--surf-connecte"><span class="status--surf-connecte"> 🎉 Ne ratez pas cette offre d'abonnement pour le Black Friday : <u><b>1€ le premier mois</b></u> d'abonnement numérique <strike>(14,90€)</strike></span></p>
		&nbsp;

		<p><a aria-label="Je m'abonne pour 8 euros par mois" class="r-btn2" data-slg-action="CTA desktop" data-slg-offer="[%requestValue('OFFER')%] CTA desktop" data-slg-tracker="[%requestValue('OFFER')%] CTA desktop" href="https://espace-abonnement.lavoixdunord.fr/content/integrale-web-1e-black-friday">J'en profite</a></p>
	</div>
	<!-- Bannière promotionnelle d'abonnement mobile -->

	<div class="r-selligent--surf-connecte-content -only-mobile" style="background-color: transparent; font-size: small;">
		<p class="title--surf-connecte"><span class="status--surf-connecte"> 🎉 Offre Black Friday : <u><b>1€ le premier mois</b></u></span></p>
		<a aria-label="Je m'abonne pour 8 euros par mois" class="r-btn2" data-slg-action="CTA mobile" data-slg-offer="[%requestValue('OFFER')%] CTA mobile" data-slg-tracker="[%requestValue('OFFER')%] CTA mobile" href="https://espace-abonnement.lavoixdunord.fr/content/integrale-web-1e-black-friday">J'en profite</a>
	</div>
	<style type="text/css">.r-selligent--surf-connecte p span {
		font-weight: normal;
		color: white;
	}
	
	.r-selligent--surf-connecte .r-selligent--surf-connecte-content::before {
			background-color: #D72482;
		}
		
	.r-selligent--surf-connecte .r-selligent--surf-connecte-content {
		padding: auto;
	}

        .r-btn2 {
        	display: inline-block;
            background-color: #0097CF;
            color: white;
            font-weight: bold;
            border-radius: 15px;
            font-size: 1em;
            padding: 10px 15px;
            text-decoration: none;
            cursor: pointer;
        }

        .r-btn2:hover {
        	display: inline-block;
            background-color: black;
            color: white;
            text-decoration: none;
        }
	</style>
	<!-- TRACKING GENERIQUE --><script type="text/javascript">
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            'event': 'slg_offer_load',
            'loaded_offer': '[%requestValue('OFFER')%] Promo - [%requestValue('ACTION')%][%if(isnotempty(requestValue('CX_EDITOR')),concat(' - ',requestValue('CX_EDITOR')),'')%][%if(isnotempty(requestValue('CX_SUB_EDITOR')),concat(' - ',requestValue('CX_SUB_EDITOR')),'')%][%if(isnotempty(requestValue('CX_MEMBERSTATUS')),concat(' - ',requestValue('CX_MEMBERSTATUS')),'')%]'
        });
    </script>
</body>
</html>
