<html>
<head>
	<title></title>
</head>
<body>
	<!-- Bannière promotionnelle d'abonnement desktop -->
	<div class="r-selligent--surf-connecte-content -only-desktop" style="background-color: #FFF6A3;">
		<p class="title--surf-connecte"><span class="status--surf-connecte"> 🎉 Offre spéciale 80 ans de La Voix du Nord : <u style="color: #0854E8;">8€ par mois</u></span></p>

		<p><a aria-label="Je m'abonne pour 8 euros par mois" class="r-btn2" data-slg-action="CTA desktop" data-slg-offer="[%requestValue('OFFER')%] CTA desktop" data-slg-tracker="[%requestValue('OFFER')%] CTA desktop" href="https://espace-abonnement.lavoixdunord.fr/80_ans">J'en profite</a></p>
	</div>
	<!-- Bannière promotionnelle d'abonnement mobile -->

	<div class="r-selligent--surf-connecte-content -only-mobile" style="background-color: #FFF6A3;">
		<p class="title--surf-connecte"><span class="status--surf-connecte"> 🎉 Offre spéciale : <u style="color: #0854E8;">8€/mois</u></span></p>
		<a aria-label="Je m'abonne pour 8 euros par mois" class="r-btn2" data-slg-action="CTA mobile" data-slg-offer="[%requestValue('OFFER')%] CTA mobile" data-slg-tracker="[%requestValue('OFFER')%] CTA mobile" href="https://espace-abonnement.lavoixdunord.fr/80_ans">J'en profite</a>
	</div>
	<style type="text/css">.r-selligent--surf-connecte .r-selligent--surf-connecte-content::before {
			background-color: #FFF6A3;
		}

        .r-btn2 {
            background-color: #FDC800;
            color: black;
            font-weight: bold;
            border-radius: 5px;
            font-size: 1.1em;
            padding: 10px 15px;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .r-btn2:hover {
            background-color: #0065B1;
            color: white;
            text-decoration: none;
            transform: scale(1.05);
        }
	</style>
	<!-- TRACKING GENERIQUE --><script type="text/javascript">
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            'event': 'slg_offer_load',
            'loaded_offer': '[%requestValue('OFFER')%] Promo - [%requestValue('ACTION')%][%if(isnotempty(requestValue('CX_EDITOR')),concat(' - ',requestValue('CX_EDITOR')),'')%][%if(isnotempty(requestValue('CX_SUB_EDITOR')),concat(' - ',requestValue('CX_SUB_EDITOR')),'')%][%if(isnotempty(requestValue('CX_MEMBERSTATUS')),concat(' - ',requestValue('CX_MEMBERSTATUS')),'')%]'
        });
    </script>
</body>
</html>
