<html>
<head>
	<title></title>
</head>
<body>
	<div class="r-selligent--surf-connecte-content -only-desktop">
		<p class="title--surf-connecte"><span class="status--surf-connecte"> ⚽ Gagnez 2 places pour le Derby du Nord ! </span></p>

		<p><a class="r-btn-derby" data-slg-action="CTA desktop" data-slg-tracker="[%requestValue('OFFER')%] CTA desktop" 
		href="https://www.lavoixdunord.fr/grand-jeu-derby">Je joue</a></p>
	</div>

	<div class="r-selligent--surf-connecte-content -only-mobile">
		<p class="title--surf-connecte"><span class="status--surf-connecte"> ⚽ Gagnez 2 places pour le Derby ! </span></p>
		<a class="r-btn-derby" data-slg-action="CTA mobile" data-slg-tracker="[%requestValue('OFFER')%] CTA mobile" 
		href="https://www.lavoixdunord.fr/grand-jeu-derby">Je joue</a>
	</div>
	<style type="text/css">.r-btn-derby {
            background-color: red;
            color: white;
            font-weight: bold;
            border-radius: 5px;
            padding: 8px 12px;
            text-decoration: none;
            cursor: pointer;
        }
        .r-btn-derby:hover {
        	background-color: black;
        	color: white;
        	text-decoration: none;
        }
	</style>
	<!-- TRACKING GENERIQUE --><script type="text/javascript">
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            'event': 'slg_offer_load',
            'loaded_offer': '[%requestValue('OFFER')%] - [%requestValue('ACTION')%][%if(isnotempty(requestValue('CX_EDITOR')),concat(' - ',requestValue('CX_EDITOR')),'')%][%if(isnotempty(requestValue('CX_SUB_EDITOR')),concat(' - ',requestValue('CX_SUB_EDITOR')),'')%][%if(isnotempty(requestValue('CX_MEMBERSTATUS')),concat(' - ',requestValue('CX_MEMBERSTATUS')),'')%]'
        });
    </script>
</body>
</html>